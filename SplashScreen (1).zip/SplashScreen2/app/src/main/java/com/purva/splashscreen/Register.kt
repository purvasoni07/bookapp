package com.purva.splashscreen

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_register.*

class Register : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        btnRegis.setOnClickListener{

            val intent= Intent(this@Register,LoginPage::class.java)
            Toast.makeText(this@Register,"Registered",Toast.LENGTH_SHORT).show()
            startActivity(intent)

        }
    }
}