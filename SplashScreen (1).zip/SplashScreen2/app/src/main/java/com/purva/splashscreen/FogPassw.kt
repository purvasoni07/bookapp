package com.purva.splashscreen

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_fog_passw.*

class FogPassw : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_fog_passw)

        btnSaved.setOnClickListener{




            val intent=Intent(this@FogPassw,LoginPage::class.java)
            Toast.makeText(this@FogPassw, "OTP SENT", Toast.LENGTH_LONG).show()
            startActivity(intent)
        }
    }
}