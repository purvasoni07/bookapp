package com.purva.splashscreen

import android.content.Context
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText
import android.widget.TextView
import kotlinx.android.synthetic.main.activity_after_login.*

class AfterLogin : AppCompatActivity() {

    var titleName:String?="Bar"

    lateinit var mobileNumber:EditText
    lateinit var password:EditText

    lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        sharedPreferences=getSharedPreferences(getString(R.string.Preference_file),Context.MODE_PRIVATE)
        setContentView(R.layout.activity_after_login)

        titleName=sharedPreferences.getString("Title","Bar")

        title=titleName

        var intent=intent


        val mobileNumber = intent.getStringExtra("mobileNumber")
        val password = intent.getStringExtra("password")


        val etMobileNumber =findViewById<TextView>(R.id.etMobileNumber)
        val etPassword = findViewById<TextView>(R.id.etPassword)

        etMobileNumber.text= "MobileNumber =   "+mobileNumber
        etPassword.text="Password =   "+password



//        mobileNumber = findViewById(R.id.etMobileNumber)




         


    }


}