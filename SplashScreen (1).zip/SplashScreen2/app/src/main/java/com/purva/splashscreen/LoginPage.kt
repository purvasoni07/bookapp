package com.purva.splashscreen

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_login_page.*
import kotlinx.android.synthetic.main.activity_register.*

class LoginPage : AppCompatActivity() {

    lateinit var etMob :EditText
    lateinit var etPass :EditText
    lateinit var btnLogin :Button
    lateinit var btnFogPas :EditText
    lateinit var btnDontAcc :EditText
    lateinit var sharedPreferences: SharedPreferences

    val validMobileNum = "123"
    val validPassword = arrayOf("thor","ron")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)


        sharedPreferences=getSharedPreferences(getString(R.string.Preference_file),Context.MODE_PRIVATE)

        val isLoggedIn = sharedPreferences.getBoolean("isLoggedIn",false)

        setContentView(R.layout.activity_login_page)

        if (isLoggedIn){
            val intent=Intent(this@LoginPage,AfterLogin::class.java)
            startActivity(intent)
            finish()
        }

        etMob = findViewById(R.id.etMob)
        etPass = findViewById(R.id.etPass)
        btnLogin = findViewById(R.id.btnLogin)
        btnFogPas = findViewById(R.id.btnFogPass)
        btnDontAcc = findViewById(R.id.btnDontAcc)

        val intent=Intent(this@LoginPage,AfterLogin::class.java)



        btnLogin.setOnClickListener {
            val mobileNumber = etMob.text.toString()
            val password = etPass.text.toString()

            if (mobileNumber==validMobileNum){

                if (password==validPassword[0]){

                    intent.putExtra("mobileNumber",  etMob .text.toString())
                    intent.putExtra("password", etPass.text.toString())
                    savePreference(password)
                    startActivity(intent)
                }

                if (password==validPassword[1]){

                    intent.putExtra("mobileNumber", etMob .text.toString())
                    intent.putExtra("password", etPass.text.toString())
                    savePreference(password)
                    startActivity(intent)

                }


            }else{
                Toast.makeText(this@LoginPage, "Wrong", Toast.LENGTH_SHORT).show()

            }

        }

        btnDontAcc.setOnClickListener{
            val intent=Intent(this@LoginPage,Register::class.java)
            startActivity(intent)
        }

        btnFogPas.setOnClickListener{
            val intent=Intent(this@LoginPage,FogPassw::class.java)
            startActivity(intent)
        }
    }
    override fun onPause(){
        super.onPause()
        finish()
    }


    fun savePreference(title:String){
        sharedPreferences.edit().putBoolean("isLoggedIn",true).apply()
        sharedPreferences.edit().putString("Title",title).apply()


    }
}


//sharedPreferences.edit().putString("mobileNumber", mobileNumber).apply()   to save the mobile num
//
//  //sharedPreferences.edit().putString("mobileNumber", mobileNumber).apply()            to extract it from sharedpref